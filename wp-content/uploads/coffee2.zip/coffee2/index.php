<?php get_header(); ?>

<?php if(have_posts()): $i = 0; ?>
<?php while(have_posts()): the_post(); ?>

<?php
if ($i<1) {
    $class = 'lead';
} else if ($i<3) {
    $class = 'article';
} else {
    $class = 'mention';
}
?>

<div class="<?php echo $class; ?>">
    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <p class="date"><?php the_time('j F Y'); ?></p>
<?php
if ($i<1) {
    the_content('');
} else if ($i<3) {
    the_excerpt();
} else {
    echo get_post_meta(the_ID(), 'summary', true);
}
?>
<p class="continue"><?php
if ($i<3) {
?>
<a href="<?php the_permalink(); ?>#comments" class="comments"><?php comments_number("0 comments", "1 comment", "% comments"); ?></a>
<?php
}
?><a href="<?php the_permalink(); ?>">continue reading...</a></p>
</div>

<?php $i++; endwhile; // have_posts ?>
<?php endif; // have_posts ?>

<div class="pages">
<?php
if(function_exists('wp_pagenavi')) {
    wp_pagenavi();
} else {
?>
<ol>
    <li class="newer"><?php prev_posts_link('Newer'); ?></li>
    <li class="older"><?php next_posts_link('Older'); ?></li>
</ol>
<?php } // else wp_pagenavi ?>
</div>

<?php get_footer(); ?>
