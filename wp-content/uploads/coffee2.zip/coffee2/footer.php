<div class="colophon">

<img alt="James." height="160" width="240" src="noimg.png" />
<p>James Socol makes web sites for <a href="http://www.mozilla.com/">Mozilla</a>.
He also makes <a href="http://todaysmeet.com/">TodaysMeet</a> and a few other
<a href="http://jamessocol.com/projects/">small projects</a>. Previously, he
worked at Michigan State University.</p>

<p>James currently lives in Silicon Valley.</p>

<ul class="the-end">
    <li><a href="http://jamessocol.com/portfolio/">Portfolio</a></li>
    <li><a href="http://twitter.com/jamessocol">Twitter</a></li>
    <li><a href="/contact/">Contact</a></li>
</ul>
</div>

<?php wp_footer(); ?>

</body>
</html>

