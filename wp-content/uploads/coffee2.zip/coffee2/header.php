<!DOCTYPE html>
<head <?php language_attributes(); ?>>
    <meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

    <title><?php if ( is_single() ) { wp_title(); echo " | "; } bloginfo('name'); ?></title>

    <link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" />
    <link rel="alternate" type="application/xml+atom" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

    <?php wp_head(); ?>
</head>

<body>

<div id="header">

    <h1><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></h1>

    <p class="tagline"><?php bloginfo('description'); ?></p>

</div>


